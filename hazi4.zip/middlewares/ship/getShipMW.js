/**
 * Betölti egy hajót az adatbázisból a :ship paraméter alapján
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};