/**
 * Betölti a kalózokat az adatbázisból
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};