/**
 * Betölti egy kalózt az adatbázisból a :pirate paraméter alapján
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};