/**
 * Using the template engine render the values into the template
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};