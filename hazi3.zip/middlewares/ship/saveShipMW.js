/**
 * Elmenti a hajót az adatbázisba
 * Ha kap egy hajót akkor update, egyébként újat hoz létre
 * Átrányít a / -re, ha sikeres
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};